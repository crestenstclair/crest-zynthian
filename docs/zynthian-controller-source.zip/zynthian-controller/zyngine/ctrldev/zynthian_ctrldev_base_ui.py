#!/usr/bin/python3
# -*- coding: utf-8 -*-
# ******************************************************************************
# ZYNTHIAN PROJECT: Zynthian GUI
#
# Zynthian Control Device Mode Handler classes
#
# Copyright (C) 2024 Oscar Acena <oscaracena@gmail.com>
#
# ******************************************************************************
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# For a full copy of the GNU General Public License see the LICENSE.txt file.
#
# ******************************************************************************

# FIXME: This implementation is coupled with the graphical user interface, and it
#        should not! Move the implementation to its proper location (gui) and/or
#        provide access to it by CUIA handlers.

from threading import Thread

from zyngui import zynthian_gui_config
from zyngine.ctrldev.zynthian_ctrldev_base_extended import *


# --------------------------------------------------------------------------
# Extended Base class for mode handlers, with UI related methods
# --------------------------------------------------------------------------
class ModeHandlerBase(ModeHandlerBase):

    # FIXME: This way avoids to show Zynpad every time, BUT is coupled to UI!
    def _show_pattern_editor(self, seq=None):
        if seq is not None:
            self._select_launcher(*seq)
        zynthian_gui_config.zyngui.screens["launcher"].edit_pattern()
        
    def _select_launcher(self, phrase, midi_chan):
        self._zynseq.select_phrase(phrase)
        pos = self._chain_manager.get_pos_by_midi_chan(midi_chan)
        self._chain_manager.set_active_chain_by_index(pos[0])
        self._zynseq.libseq.selectSequence(self._zynseq.scene, phrase, midi_chan)

    # This SHOULD not be coupled to UI! This is needed because when the pattern is changed in
    # zynseq, it is not reflected in pattern editor.
    def _refresh_pattern_editor(self):
        zynpad = zynthian_gui_config.zyngui.screens["launcher"]
        patted = zynthian_gui_config.zyngui.screens['pattern_editor']
        pattern = self._zynseq.libseq.getPattern(self._zynseq.scene, self._zynseq.phrase, self._zynseq.chan, 0, 0)

        self._state_manager.start_busy("load_pattern", f"loading pattern {pattern}")
        patted.bank = zynpad.bank
        patted.sequence = zynpad.selected_pad
        patted.load_pattern(pattern)
        self._state_manager.end_busy("load_pattern")

    # FIXME: This SHOULD not be coupled to UI!
    def _get_selected_sequence(self):
        return zynthian_gui_config.zyngui.screens["launcher"].selected_pad

    # FIXME: This SHOULD not be coupled to UI!
    def _get_selected_step(self):
        pe = zynthian_gui_config.zyngui.screens["pattern_editor"]
        return pe.keymap[pe.selected_cell[1]]['note'], pe.selected_cell[0]

    # FIXME: This SHOULD be a CUIA, not this hack! (is coupled with UI)
    # NOTE: It runs in a thread to avoid lagging the hardware interface
    def _update_ui_arranger(self, cell_selected=(None, None)):
        logging.debug('Arranger turned off until further notice')
        return
        def run():
            arranger = zynthian_gui_config.zyngui.screens["arranger"]
            arranger.select_cell(*cell_selected)
            if cell_selected[1] is not None:
                arranger.draw_row(cell_selected[1])
        Thread(target=run, daemon=True).start()

# --------------------------------------------------------------------------
