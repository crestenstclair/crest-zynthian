/**    Track class methods implementation **/

#include "track.h"
#include <cmath>
#include <random>
#include <stdlib.h>

// Random Normal Distribution
std::random_device rd{};
std::mt19937 gen{rd()};
// values near the mean are the most likely
// standard deviation affects the dispersion of generated values from the mean
std::normal_distribution d{0.0, 1.0};

bool Track::addPattern(uint32_t position, Pattern* pattern, bool force) {
    // Find (and remove) overlapping patterns
    uint32_t nStart = position;
    uint32_t nEnd = nStart + pattern->getLength();
    for (uint32_t nClock = 0; nClock <= position + pattern->getLength(); ++nClock) {
        if (m_mPatterns.find(nClock) != m_mPatterns.end()) {
            Pattern* pPattern = m_mPatterns[nClock];
            uint32_t nExistingStart = nClock;
            uint32_t nExistingEnd = nExistingStart + pPattern->getLength();

            if ((nStart >= nExistingStart && nStart < nExistingEnd) || (nEnd > nExistingStart && nEnd <= nExistingEnd)) {
                if (!force)
                    return false;
                // Found overlapping pattern so remove from track but don't delete (that is responsibility of PatternManager)
                m_mPatterns.erase(nClock);
                if (m_nCurrentPatternPos == nClock)
                    m_nCurrentPatternPos = -1;
            }
        }
    }
    m_mPatterns[position] = pattern;
    if (m_nTrackLength < position + pattern->getLength())
        m_nTrackLength = position + pattern->getLength(); //!@todo Does this shrink and stretch scene?
    m_bChanged = true;
    return true;
}

void Track::removePattern(uint32_t position) {
    m_mPatterns.erase(position);
    if (m_nCurrentPatternPos == position)
        m_nCurrentPatternPos = -1;
    updateLength();
    m_bChanged = true;
}

Pattern* Track::getPattern(uint32_t position) {
    auto it = m_mPatterns.find(position);
    if (it == m_mPatterns.end())
        return NULL;
    return it->second;
}

Pattern* Track::getPatternAt(uint32_t position) {
    for (auto it = m_mPatterns.begin(); it != m_mPatterns.end(); ++it) {
        if (it->first <= position && position + 1 < it->first + it->second->getLength())
            return it->second;
    }
    return NULL;
}

uint8_t Track::getChannel() { return m_nChannel; }

void Track::setChannel(uint8_t channel) {
    if (channel > 15)
        return;
    m_nChannel = channel;
    m_bChanged = true;
}

uint8_t Track::getOutput() { return m_nOutput; }

void Track::setOutput(uint8_t output) {
    m_nOutput = output;
    m_bChanged = true;
}

uint8_t Track::clock(uint32_t nTime, uint32_t nPosition, bool bSync) {
    if (m_nTrackLength == 0)
        return 0;
    if (m_bMute)
        return 0;

    if (m_mPatterns.find(nPosition) != m_mPatterns.end()) {
        // Playhead at start of pattern
        // fprintf(stderr, "Start of pattern\n");
        m_nCurrentPatternPos = nPosition;
        m_nNextStep = 0;
        m_nNextEvent = 0;
        m_nClkPerStep = m_mPatterns[m_nCurrentPatternPos]->getClocksPerStep();
        if (m_nClkPerStep == 0)
            m_nClkPerStep = 1;
        m_nEventValue = -1;
        m_nDivCount = 0; // Trigger first step immediately
        m_nLastClockTime = nTime;
        // fprintf(stderr, "m_nCurrentPatternPos: %u m_nClkPerStep: %u\n", m_nCurrentPatternPos, m_nClkPerStep);
    } else if (m_nCurrentPatternPos >= 0 && nPosition >= m_nCurrentPatternPos + m_mPatterns[m_nCurrentPatternPos]->getLength()) {
        // At end of pattern
        // fprintf(stderr, "End of pattern\n");
        m_nCurrentPatternPos = -1;
        m_nNextEvent = -1;
        m_nNextStep = 0;
        m_nClkPerStep = 1;
        m_nEventValue = -1;
        m_nDivCount = 0;
    } else {
        // Within pattern
        ++m_nDivCount;
        // fprintf(stderr, "Next Step: %d, Next Event: %d DivCount: %u\n", m_nNextStep, m_nNextEvent, m_nDivCount);
    }

    if (m_nCurrentPatternPos >= 0 && m_nDivCount >= m_nClkPerStep) {
        // Reached next step
        // fprintf(stderr, "Reached next step \n");
        m_nLastClockTime = nTime;
        m_nDivCount = 0;
        ++m_nNextStep;
        m_nNextEvent = m_mPatterns[m_nCurrentPatternPos]->getFirstEventAtStep(m_nNextStep); //!@todo Could disable this check only when not editing pattern
    }

    return m_nCurrentPatternPos >= 0 && m_nDivCount == 0;
}

bool get_skip_from_freq(uint8_t freq, uint32_t nCount) {
    uint8_t n = 1 + (freq >> 1);
    uint8_t skip = freq & 0x1;
    if (n == 1) {
        if (skip) return false;     // Skip never (note enabled)
        else return true;           // Skip always (note disabled)
    }
    else {
        // if skip == 1 => skip each n counts
        if (skip) {
            if (nCount % n == n - 1) return true;
            else return false;
        }
        // if skip == 0 => play each n counts
        else {
            if (nCount % n != n - 1) return true;
            else return false;
        }
    }
}

SEQ_EVENT* Track::getEvent(uint32_t nCount) {
    // This function is called repeatedly for each clock period until no more events are available to populate JACK MIDI output schedule
    static SEQ_EVENT seqEvent;             // A MIDI event timestamped for some imminent or future time
    static uint32_t nEventEndTime;         // End of event time (optimization)
    static uint32_t nStutterSpeed = 0;     // Current stutter speed for this event
    static uint32_t nStutterCount = 0;     // Count stutters already added to this event
    static uint32_t nInterpolateCount = 0; // Count interpolations already added to this event
    static uint32_t nInterpolateNum = 0;   // Number of interpolation points for this event
    static float fInterpolateDelta = 0;    // Value delta for each interpolation point
    if (m_nCurrentPatternPos < 0 || m_nNextEvent < 0)
        return NULL; //!@todo Can we stop between note on and note off being processed resulting in stuck note?
    // Track is being played and playhead is within a pattern
    Pattern* pPattern = m_mPatterns[m_nCurrentPatternPos];
    StepEvent* pEvent = pPattern->getEventAt(m_nNextEvent); // Don't advance event here because need to interpolate

    // Found event at (or before) this step
    if (pEvent && pEvent->getPosition() == m_nNextStep) {

        // We have reached the end of interpolation so move on to next event
        if (m_nEventValue == pEvent->getValue2end()) {
            m_nEventValue = -1;
            pEvent = pPattern->getEventAt(++m_nNextEvent);
            // No more events or next event is not this step so move to next step
            if (!pEvent || pEvent->getPosition() != m_nNextStep) {
                return NULL;
            }
        }

        uint8_t nCommand = pEvent->getCommand();

        seqEvent.output = m_nOutput;
        //fprintf(stderr, "  found event at %u => %x, %u, %u\n", m_nNextStep, nCommand, pEvent->getValue1start(), pEvent->getValue2start());

        // Last event already finished => Start new event!
        if (m_nEventValue == -1) {
            // Play Frequency & Chance
            if (nCommand == MIDI_NOTE_ON) {
                // Play frequency
                bool skip = get_skip_from_freq(pEvent->getPlayFreq(), nCount);
                // Play chance (probability) => concatenated with frequency calc
                if (!skip) {
                    if (unsigned(RAND_MAX * pPattern->getPlayChance() * pEvent->getPlayChance()) < rand())
                        skip = true;
                }
                if (skip) {
                    m_nEventValue = pEvent->getValue2end();
                    seqEvent.msg.command = 0xFE;
                    return &seqEvent;
                }
            }
            seqEvent.msg.command = nCommand | m_nChannel;
            // Start value (interpolation)
            m_nEventValue = pEvent->getValue2start();
            // Offset (fraction of step => float)
            m_fEventOffset = pEvent->getOffset();
            // Setup interpolation
            nInterpolateCount = 0;
            nInterpolateNum = pEvent->getDuration() * pPattern->getClocksPerStep();
            fInterpolateDelta = ((float)pEvent->getValue2end() - (float)pEvent->getValue2start()) / nInterpolateNum;
            // Note quantization, swing & time humanization
            if (nCommand == MIDI_NOTE_ON) {
                // Real-time quantization (step quantization
                uint8_t qn = pPattern->getQuantizeNotes();
                // Quantize to step boundary (qn = 1)
                if (qn == 1) {
                    if (m_fEventOffset > 0.5) m_fEventOffset = 1.0;
                    else m_fEventOffset = 0.0;
                }
                // Quantize to step fraction boundary (1/qn => 1/2, 1/3, 1/4, 1/6, 1/8, ...)
                else if (qn > 1) {
                    float os = m_fEventOffset;
                    float m = m_fEventOffset * qn;
                    uint8_t mi = (int)m;
                    if ((m - mi) > 0.5) m_fEventOffset = (float)(mi + 1) / (float)qn;
                    else m_fEventOffset = (float)mi / (float)qn;
                    //printf("Event %d with Offset %f => Quantized (1/%d) to %f\n", pEvent->getPosition(), os, qn, m_fEventOffset);
                }
                // Swing => Add to offset
                uint32_t swingDiv = pPattern->getSwingDiv();
                float swingAmount = pPattern->getSwingAmount();
                uint32_t swingStep = m_nNextStep + swingDiv;
                if (m_fEventOffset > 0.5) swingStep++;
                if (swingStep % (2 * swingDiv) == 0) {
                    m_fEventOffset += swingAmount * swingDiv / 2;
                }
                // Time humanization => Add to offset
                float humanTime = pPattern->getHumanTime();
                if (humanTime > 0.0)
                    m_fEventOffset += humanTime * d(gen);
                // Setup stutter
                nStutterCount = 0;
                nStutterSpeed = pEvent->getStutterSpeed();
                if (nStutterSpeed > 0) {
                    // Stutter frequency
                    bool skip = get_skip_from_freq(pEvent->getStutterFreq(), nCount);
                    // Stutter chance (probability) => concatenated with frequency calc
                    if (!skip) {
                        if (unsigned(RAND_MAX * pEvent->getStutterChance()) < rand())
                            skip = true;
                    }
                    if (skip)
                        nStutterSpeed = 0;
                    else
                        // If stutter FX is fade-in => start interpolation from lowest velocity value
                        if (pEvent->getStutterVelfx() == STUTTER_VELFX_FADEIN) {
                            nInterpolateCount = pPattern->getClocksPerStep() / nStutterSpeed;
                            m_nEventValue = 1 - fInterpolateDelta * nInterpolateCount;
                        }
                }
            }
            else {
                //nStutterCount = 0;
                nStutterSpeed = 0;
            }
            // Calculate event scheduled time
            seqEvent.time = m_nLastClockTime + m_fEventOffset * pPattern->getClocksPerStep();
            // Calculate note-off event scheduled time
            // -1 to send note-off one tick before next step
            nEventEndTime = seqEvent.time + pEvent->getDuration() * pPattern->getClocksPerStep() - 1;
        }
        // Event already started
        else if (m_nEventValue != pEvent->getValue2end()) {
            // Process note stutter => Normal note off is processed like stutter. By default a note has stutter=0.
            if (nCommand == MIDI_NOTE_ON) {
                // Stutter enabled => Add note off/on for each stutter
                if (nStutterSpeed > 0) {
                    uint32_t clocks_per_step= pPattern->getClocksPerStep();
                    // Stutter speed-ramp FX
                    uint8_t speed = nStutterSpeed;
                    switch (pEvent->getStutterRamp()) {
                        case STUTTER_RAMP_NONE:
                            break;
                        case STUTTER_RAMP_UP:
                            speed += (seqEvent.time - m_nLastClockTime) / clocks_per_step;
                            break;
                        case STUTTER_RAMP_DOWN:
                            speed += pEvent->getDuration() - (seqEvent.time - m_nLastClockTime) / clocks_per_step;
                            break;
                    }
                    // Calculate stutter event time
                    uint32_t nclocks;
                    if (speed > clocks_per_step) uint32_t nclocks = 1;
                    else if (speed <= 0) nclocks = clocks_per_step;
                    else nclocks = clocks_per_step / speed;
                    uint32_t stutter_time = seqEvent.time + nclocks;
                    // If not reached end of note
                    if (stutter_time < nEventEndTime) {
                        seqEvent.time = stutter_time;
                        // Stutter alternate note-off and note-on events
                        seqEvent.msg.command = (nStutterCount % 2 ? MIDI_NOTE_ON : MIDI_NOTE_OFF) | m_nChannel;
                        nStutterCount++;
                        // Stutter velocity FX => Interpolate velocity
                        nInterpolateCount += nclocks;
                        switch (pEvent->getStutterVelfx()) {
                            // Flat
                            case STUTTER_VELFX_NONE:
                                break;
                            // Fade-in
                            case STUTTER_VELFX_FADEIN:
                                m_nEventValue = - fInterpolateDelta * nInterpolateCount;
                                break;
                            // Fade-out
                            case STUTTER_VELFX_FADEOUT:
                                m_nEventValue = pEvent->getValue2start() + fInterpolateDelta * nInterpolateCount;
                                break;
                        }
                    }
                    // End of note
                    else {
                        seqEvent.time = nEventEndTime;
                        seqEvent.msg.command = MIDI_NOTE_OFF | m_nChannel;
                        m_nEventValue = pEvent->getValue2end(); // send end value
                    }
                // Stutter disabled (stutter speed = 0)
                } else {
                    seqEvent.time = nEventEndTime;
                    seqEvent.msg.command = MIDI_NOTE_OFF | m_nChannel;
                    m_nEventValue = pEvent->getValue2end();     // send end value
                }
            }
            // CC interpolation => one value per clock but don't repeat values
            else if (nCommand == MIDI_CONTROL) {
                int8_t start_value = pEvent->getValue2start();
                int8_t next_value;
                do {
                    seqEvent.time++;
                    nInterpolateCount++;
                    next_value = start_value + fInterpolateDelta * nInterpolateCount;
                } while (seqEvent.time < nEventEndTime && next_value == m_nEventValue);
                // If reached event's end time, send end value
                if (seqEvent.time >= nEventEndTime) {
                    seqEvent.time = nEventEndTime;
                    next_value = pEvent->getValue2end();     // send end value
                }
                // Don't send repeated values
                if (next_value == m_nEventValue) {
                    seqEvent.msg.command = 0xFE;
                    return &seqEvent;
                }
                seqEvent.msg.command = nCommand | m_nChannel;
                m_nEventValue = next_value;
                //fprintf(stderr, "Scheduling CC%u interpolated value => %u, %u\n", pEvent->getValue1start(), seqEvent.time, m_nEventValue);
            }
        }

        // Set MIDI event values
        seqEvent.msg.value1 = pEvent->getValue1start();
        if (nCommand == MIDI_NOTE_ON) {
            // Velocity humanization
            float humanVelo = pPattern->getHumanVelo();
            if (humanVelo > 0.0) {
                int16_t dvelo = int16_t(humanVelo * d(gen));
                seqEvent.msg.value2 = int8_t(std::min(std::max(int16_t(m_nEventValue) + dvelo, 0), 127));
            } else {
                seqEvent.msg.value2 = m_nEventValue;
            }
        } else {
            seqEvent.msg.value2 = m_nEventValue;
        }

        return &seqEvent;
    }
    m_nEventValue = -1;
    // m_fEventOffset = 0;
    //        if(++m_nNextStep >= pPattern->getSteps())
    //            m_nNextStep = 0;
    return NULL;
}

uint32_t Track::updateLength() {
    m_nTrackLength = 0;
    m_bEmpty = true;
    for (auto it = m_mPatterns.begin(); it != m_mPatterns.end(); ++it) {
        if (it->first + it->second->getLength() > m_nTrackLength)
            m_nTrackLength = it->first + it->second->getLength();
        if (it->second->getLastStep() != -1)
            m_bEmpty = false;
    }
    return m_nTrackLength;
}

uint32_t Track::getLength() { return m_nTrackLength; }

void Track::clear() {
    m_mPatterns.clear();
    m_nTrackLength = 0;
    m_nEventValue = -1;
    m_nCurrentPatternPos = -1;
    m_nNextEvent = -1;
    m_nNextStep = 0;
    m_nClkPerStep = 1;
    m_nDivCount = 0;
    m_bChanged = true;
}

void Track::setPosition(uint32_t position) {
    m_nDivCount = 0;
    m_nNextStep = position / m_nClkPerStep;
    // fprintf(stderr, "setPosition: next step: %d\n", m_nNextStep);
    m_nNextEvent = -1; // Avoid playing wrong pattern
    for (auto it = m_mPatterns.begin(); it != m_mPatterns.end(); ++it) {
        if (it->first <= position && it->first + it->second->getLength() > position) {
            // Found pattern that spans position
            m_nCurrentPatternPos = it->first;
            break;
        }
    }
}

uint32_t Track::getNextPattern(uint32_t previous) {
    if (m_mPatterns.size() == 0)
        return 0xFFFFFFFF;
    if (previous == 0xFFFFFFFF)
        return m_mPatterns.begin()->first;
    auto it = m_mPatterns.find(previous);
    if (++it == m_mPatterns.end())
        return 0xFFFFFFFF;
    return it->first;
}

size_t Track::getPatterns() { return m_mPatterns.size(); }

void Track::setMap(uint8_t map) { m_nMap = map; }

uint8_t Track::getMap() { return m_nMap; }

void Track::solo(bool solo) { m_bSolo = solo; }

bool Track::isSolo() { return m_bSolo; }

void Track::mute(bool mute) {
    m_bMute = mute;
    m_nEventValue = -1;
    m_nCurrentPatternPos = -1;
    m_nNextEvent = -1;
}

bool Track::isMuted() { return m_bMute; }

void Track::setModified() { m_bChanged = true; }

bool Track::isModified() {
    if (m_bChanged) {
        m_bChanged = false;
        return true;
    }
    return false;
}

Pattern* Track::getPatternByIndex(size_t index) {
    size_t nIndex = 0;
    for (auto it = m_mPatterns.begin(); it != m_mPatterns.end(); ++it) {
        if (index == nIndex)
            return it->second;
        ++nIndex;
    }
    return NULL;
}

uint32_t Track::getPatternPositionByIndex(size_t index) {
    if (index >= m_mPatterns.size())
        return -1;
    auto it = m_mPatterns.begin();
    while (index--)
        ++it;
    return it->first;
}

uint32_t Track::getPatternPosition(Pattern* pattern) {
    for (auto it = m_mPatterns.begin(); it != m_mPatterns.end(); ++it) {
        if (it->second == pattern)
            return it->first;
    }
    return -1;
}

bool Track::isEmpty() { return m_bEmpty; }
