#pragma once
#include "constants.h"
#include <cstdio>
#include <memory>
#include <vector>

#define MAX_STUTTER_SPEED 32
#define STUTTER_VELFX_NONE 0
#define STUTTER_VELFX_FADEIN 1
#define STUTTER_VELFX_FADEOUT 2
#define MAX_STUTTER_VELFX 2
#define STUTTER_RAMP_NONE 0
#define STUTTER_RAMP_UP 1
#define STUTTER_RAMP_DOWN 2
#define MAX_STUTTER_RAMP 2

#define FLAG_CC_INTERPOLATION 1

/** StepEvent class provides an individual step event .
 * The event may be part of a scene, pattern or sequence. Events do not have MIDI channel which is applied by the function to play the event, e.g. pattern
 * player assigned to specific channel. Events have the concept of position which is an offset from some epoch measured in steps. The epoch depends on the
 * function using the event, e.g. pattern player may use start of pattern as epoch (position = 0). There is a starting and end value to allow interpolation of
 * MIDI events between the start and end positions.
*/
#pragma pack(1)     // Set pack to 1 to allow binary interfacing from python ctypes
class StepEvent {

  public:
    uint32_t m_nPosition;      // Start position of event in steps
    float m_fOffset;           // Offset of event position in steps
    float m_fDuration;         // Duration of event in steps

    uint8_t m_nCommand;        // MIDI command without channel
    uint8_t m_nValue1start;    // MIDI value 1 at start of event
    uint8_t m_nValue2start;    // MIDI value 2 at start of event
    uint8_t m_nValue1end;      // MIDI value 1 at end of event

    uint8_t m_nValue2end;      // MIDI value 2 at end of event
    uint8_t m_nStutterSpeed;   // Stutter speed in "retriggers every 2 steps"
    uint8_t m_nStutterVelfx;   // Stutter velocity FX (none=0, fade-out=1, fade-in=2)
    uint8_t m_nStutterRamp;    // Stutter speed ramp FX (none=0, ramp-up=1, ramp-down=2)

    uint8_t m_nPlayFreq;       // Play/Skip note each N loops: last bit => play/skip, higher bits => loop count
                               // Can be used for enabling/disabling the event: 0 => play never, 1 => play on every loop
    uint8_t m_nStutterFreq;    // Play/Skip stutter each N loops: last bit => play/skip, higher bits => loop count
                               // Can be used for enabling/disabling the stutter: 0 => never stutter, 1 => stutter on every loop
    float m_fPlayChance;       // Probability of playing (0 = not played, 0.5 = plays with 50%, 1.0 = always plays)
    float m_fStutterChance;    // Probability of stutter (0 = not stutter, 0.5 = stutters with 50%, 1.0 = always stutters)

      /** Default constructor of StepEvent object
*/
    StepEvent() {
        m_nPosition = 0;
        m_fOffset = 0.0;
        m_fDuration = 1.0;
        m_nCommand = MIDI_NOTE_ON;
        m_nValue1start = 60;
        m_nValue2start = 100;
        m_nValue1end = 60;
        m_nValue2end = 0;
        m_nStutterSpeed = 0;
        m_nStutterVelfx = STUTTER_VELFX_NONE;
        m_nStutterRamp = STUTTER_RAMP_NONE;
        m_fPlayChance = 1.0f;
        m_nPlayFreq = 1;
        m_fStutterChance = 1.0f;
        m_nStutterFreq = 1;
    };

    /** Constructor - create an instance of StepEvent object
*/
    StepEvent(uint32_t position, uint8_t command, uint8_t value1 = 0, uint8_t value2 = 0, float duration = 1.0, float offset = 0.0) {
        m_nPosition = position;
        m_fOffset = offset;
        m_fDuration = duration;
        m_nCommand = command;
        m_nValue1start = value1;
        m_nValue2start = value2;
        m_nValue1end = value1;
        if (command == MIDI_NOTE_ON)
            m_nValue2end = 0;
        else
            m_nValue2end = value2;
        m_nStutterSpeed = 0;
        m_nStutterVelfx = STUTTER_VELFX_NONE;
        m_nStutterRamp = STUTTER_RAMP_NONE;
        m_fPlayChance = 1.0f;
        m_nPlayFreq = 1;
        m_fStutterChance = 1.0f;
        m_nStutterFreq = 1;
    };

    /** Copy constructor - create an copy of StepEvent object from an existing object
*/
    StepEvent(StepEvent* pEvent) {
        m_nPosition = pEvent->m_nPosition;
        m_fOffset = pEvent->m_fOffset;
        m_fDuration = pEvent->m_fDuration;
        m_nCommand = pEvent->m_nCommand;
        m_nValue1start = pEvent->m_nValue1start;
        m_nValue2start = pEvent->m_nValue2start;
        m_nValue1end = pEvent->m_nValue1end;
        m_nValue2end = pEvent->m_nValue2end;
        m_nStutterSpeed = pEvent->m_nStutterSpeed;
        m_nStutterVelfx = pEvent->m_nStutterVelfx;
        m_nStutterRamp = pEvent->m_nStutterRamp;
        m_fPlayChance = pEvent->m_fPlayChance;
        m_nPlayFreq = pEvent->m_nPlayFreq;
        m_fStutterChance = pEvent->m_fStutterChance;
        m_nStutterFreq = pEvent->m_nStutterFreq;
    };

    StepEvent& operator=(StepEvent& ev) {
        // Guard self assignment
        if (this == &ev)
            return *this;
        m_nPosition = ev.m_nPosition;
        m_fOffset = ev.m_fOffset;
        m_fDuration = ev.m_fDuration;
        m_nCommand = ev.m_nCommand;
        m_nValue1start = ev.m_nValue1start;
        m_nValue2start = ev.m_nValue2start;
        m_nValue1end = ev.m_nValue1end;
        m_nValue2end = ev.m_nValue2end;
        m_nStutterSpeed = ev.m_nStutterSpeed;
        m_nStutterVelfx = ev.m_nStutterVelfx;
        m_nStutterRamp = ev.m_nStutterRamp;
        m_fPlayChance = ev.m_fPlayChance;
        m_nPlayFreq = ev.m_nPlayFreq;
        m_fStutterChance = ev.m_fStutterChance;
        m_nStutterFreq = ev.m_nStutterFreq;
        return *this;
    }

    // Public Getters
    uint32_t getPosition() { return m_nPosition; }
    float getOffset() { return m_fOffset; }
    float getDuration() { return m_fDuration; }
    uint8_t getCommand() { return m_nCommand; }
    uint8_t getValue1start() { return m_nValue1start; }
    uint8_t getValue2start() { return m_nValue2start; }
    uint8_t getValue1end() { return m_nValue1end; }
    uint8_t getValue2end() { return m_nValue2end; }
    uint8_t getStutterSpeed() { return m_nStutterSpeed; }
    uint8_t getStutterVelfx() { return m_nStutterVelfx; }
    uint8_t getStutterRamp() { return m_nStutterRamp; }
    float getPlayChance() { return m_fPlayChance; }
    uint8_t getPlayFreq() { return m_nPlayFreq; }
    float getStutterChance() { return m_fStutterChance; }
    uint8_t getStutterFreq() { return m_nStutterFreq; }

    // Public Setters
    void setPosition(uint32_t position) { m_nPosition = position; }
    void setOffset(float offset) { m_fOffset = offset; }
    void setDuration(float duration) { m_fDuration = duration; }
    void setValue1start(uint8_t value) { m_nValue1start = value; }
    void setValue2start(uint8_t value) { m_nValue2start = value; }
    void setValue1end(uint8_t value) { m_nValue1end = value; }
    void setValue2end(uint8_t value) { m_nValue2end = value; }
    void setStutterSpeed(uint8_t value) {
        if (value <= MAX_STUTTER_SPEED)
            m_nStutterSpeed = value;
        else
            m_nStutterSpeed = MAX_STUTTER_SPEED;
    }
    void setStutterVelfx(uint8_t value) {
        if (value <= MAX_STUTTER_VELFX)
            m_nStutterVelfx = value;
        else
            m_nStutterVelfx = MAX_STUTTER_VELFX;
    }
    void setStutterRamp(uint8_t value) {
        if (value <= MAX_STUTTER_RAMP)
            m_nStutterRamp = value;
        else
            m_nStutterRamp = MAX_STUTTER_RAMP;
    }
    void setStutter(uint8_t speed, uint8_t velfx, uint8_t ramp) {
        setStutterSpeed(speed);
        setStutterVelfx(velfx);
        setStutterRamp(ramp);
    }
    void setPlayChance(float chance) { m_fPlayChance = chance; }
    void setPlayFreq(uint8_t freq) { m_nPlayFreq = freq; }
    void setStutterChance(float chance) { m_fStutterChance = chance; }
    void setStutterFreq(uint8_t freq) { m_nStutterFreq = freq; }
};
#pragma pack()

typedef std::vector<StepEvent*> StepEventVector;

/**    Pattern class provides a group of MIDI events within period of time
*/
class Pattern {
  public:
    /** @brief  Construct pattern object
        @param  beats Quantity of beats in pattern [Optional - default:4]
        @param  stepsPerBeat Quantity of steps per beat [Optional - default: 4]
    */
    Pattern(uint32_t beats = DEFAULT_BPB, uint32_t stepsPerBeat = 4);

    /** @brief  Copy constructor
        @param  Pointer to pattern to copy
    */
    Pattern(Pattern* pattern);

    /** @brief  Destruct pattern object
    */
    ~Pattern();

    /** @brief  Copy operator
        @param  p Pattern Reference to copy
    */
    Pattern& operator=(Pattern& p);

    /** @brief  Copy+Add operator
        @param  p Pattern Reference to copy
    */
    Pattern& operator+=(Pattern& p);

    /** @brief  Paste (merge) a pattern into this
        @param  p Pointer to pattern to paste into this
        @param  dstep Quantity of steps to offset
        @param  doffset Fractional time offset
        @param  dnote Note offset
        @param  truncate False to use circular horizontal overflow. True to skip events out of step range.
    */
    void pastePattern(Pattern* p, int32_t dstep=0, float doffset=0.0, int8_t dnote=0, bool truncate=false);

    /** @brief  Create a (sub)pattern from this pattern, copying the events in the specified step & note range.
        @param  step1 step-range start
        @param  step2 step-range end
        @param  note1 note-range start
        @param  note2 note-range end
        @param  cut True to remove events from source pattern
        @retval Pattern* Pointer to a newly created pattern with the copied events. The caller must delete when not needed anymore.
    */
    Pattern* getPatternSelection(uint32_t step1=0, uint32_t step2=0xFFFFFFFF, uint8_t note1=0, uint8_t note2=127, bool cut=false);

    /** @brief  Get keys (step+note) of note events in the specified time & note range.
        @param  ev_keys pointer to integer array. It will be filled with the list of event indexes
        @param  limit size of integer array (ev_indexes)
        @param  step1 step-range start
        @param  step2 step-range end
        @param  note1 note-range start
        @param  note2 note-range end
        @retval uint32_t the number of event indexes copied into ev_indexes.
    */
    uint32_t getPatternSelectionKeys(uint32_t* ev_keys, uint32_t limit, uint32_t step1=0, uint32_t step2=0xFFFFFFFF, uint8_t note1=0, uint8_t note2=127);

    /** @brief  Add step event to pattern
        @param  position Quantity of steps from start of pattern
        @param  command MIDI command
        @param  value1 MIDI value 1
        @param  value2 MIDI value 2
        @param  duration Event duration in steps cycles
    */
    StepEvent* addEvent(uint32_t position, uint8_t command, uint8_t value1 = 0, uint8_t value2 = 0, float duration = 1.0, float offset = 0.0);

    /** @brief  Add event from existing event
        @param  pEvent Pointer to event to copy
        @retval StepEvent* Pointer to new event
    */
    StepEvent* addEvent(StepEvent* pEvent);

    /** @brief  Add note to pattern
        @param  step Quantity of steps from start of pattern at which to add note
        @param  note MIDI note number
        @param  velocity MIDI velocity
        @param  duration Duration of note in steps
        @param  offset Step fraction, from 0.0 to 1.0
        @retval bool True on success
    */
    bool addNote(uint32_t step, uint8_t note, uint8_t velocity, float duration = 1.0, float offset = 0.0);

    /** @brief  Remove note from pattern
        @param  position Quantity of steps from start of pattern at which to remove note
        @param  note MIDI note number
    */
    void removeNote(uint32_t step, uint8_t note);

    /** @brief  Remove all note events from pattern
    */
	void clearNotes();

    /** @brief  Get index of a specified note
        @param  position Quantity of steps from start of pattern at which to check for note
        @param  note MIDI note number
        @retval int32_t index of the note event in the events vector
    */
    int32_t getNoteIndex(uint32_t step, uint8_t note);

    /** @brief  Get data of a specified note
        @param  position Quantity of steps from start of pattern at which to check for note
        @param  note MIDI note number
        @param  data pointer to a struct to contain event data
        @retval int32_t index of the note event in the events vector
    */
    int32_t getNoteData(uint32_t step, uint8_t note, StepEvent* data);

    /** @brief  Set data of a specified note, excluding position, offset, command and note number (nValue1Start)
        @param  position Quantity of steps from start of pattern at which to check for note
        @param  note MIDI note number
        @param  data pointer to a struct to contain event data
        @retval int32_t index of the note event in the events vector
    */
    int32_t setNoteData(uint32_t step, uint8_t note, StepEvent* data);

    /** @brief  Get step that note starts
        @param  position Quantity of steps from start of pattern at which to check for note
        @param  note MIDI note number
        @retval int32_t Quantity of steps from start of pattern that note starts or -1 if note not found
    */
    int32_t getNoteStart(uint32_t step, uint8_t note);

    /** @brief  Get velocity of note
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval uint8_t MIDI velocity of note
    */
    uint8_t getNoteVelocity(uint32_t step, uint8_t note);

    /** @brief  Set velocity of note
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  velocity MIDI velocity
    */
    void setNoteVelocity(uint32_t step, uint8_t note, uint8_t velocity);

    /** @brief  Get duration of note
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval float Duration of note or 0 if note does not exist
    */
    float getNoteDuration(uint32_t step, uint8_t note);

    /** @brief  Get offset of note
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval float offset Step fraction, from 0.0 to 1.0
    */
    float getNoteOffset(uint32_t step, uint8_t note);

    /** @brief  Set offset of note in selected pattern
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  offset Step fraction, from 0.0 to 1.0
    */
    void setNoteOffset(uint32_t step, uint8_t note, float offset);

    /** @brief  Set note stutter
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  speed Speed in "retriggers every 2 steps"
        @param  velfx velocity speed FX (0=None, 1=fadeIn, 2=fadeOut)
        @param  ramp speed ramp FX (0=None, 1=down, 2=up)
    */
    void setStutter(uint32_t step, uint8_t note, uint8_t speed, uint8_t velfx, uint8_t ramp);

    /** @brief  Set note stutter count
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  speed Speed in "retriggers every 2 steps"
    */
    void setStutterSpeed(uint32_t step, uint8_t note, uint8_t speed);

    /** @brief  Set note stutter duration
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  velfx velocity speed FX (0=None, 1=fadeIn, 2=fadeOut)
    */
    void setStutterVelfx(uint32_t step, uint8_t note, uint8_t velfx);

    /** @brief  Set note stutter duration
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  ramp speed ramp FX (0=None, 1=down, 2=up)
    */
    void setStutterRamp(uint32_t step, uint8_t note, uint8_t ramp);

    /** @brief  Get note stutter spèed
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval uint8_t Speed in "retriggers every 2 steps"
    */
    uint8_t getStutterSpeed(uint32_t step, uint8_t note);

    /** @brief  Get note stutter velcity speed FX value
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval uint8_t velocity speed FX (0=None, 1=fadeIn, 2=fadeOut)
    */
    uint8_t getStutterVelfx(uint32_t step, uint8_t note);

    /** @brief  Get note stutter ramp FX value
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval uint8_t speed ramp FX (0=None, 1=down, 2=up)
    */
    uint8_t getStutterRamp(uint32_t step, uint8_t note);

    /** @brief  Set note play chance
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  chance Note play probability (0..1 for 0%..100%)
    */
    void setPlayChance(uint32_t step, uint8_t note, float chance);

    /** @brief  Get note play chance
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval float Chance, the note play probability (0..1 for 0%..100%)
    */
    float getPlayChance(uint32_t step, uint8_t note);

    /** @brief  Set note play frequency
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  freq Note play frequency: last bit => play/skip, higher bits => n loops to play/skip
                     Can be used for enabling/disabling the event: 0 => play never, 1 => play on every loop
    */
    void setPlayFreq(uint32_t step, uint8_t note, uint8_t freq);

    /** @brief  Get note play frequency
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval uint8_t Note play frequency: last bit => play/skip, higher bits => n loops to play/skip
    */
    uint8_t getPlayFreq(uint32_t step, uint8_t note);

    /** @brief  Set note stutter chance
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  chance Stutter play probability (0..1 for 0%..100%)
    */
    void setStutterChance(uint32_t step, uint8_t note, float chance);

    /** @brief  Get stutter chance
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval float Chance, the stutter probability (0..1 for 0%..100%)
    */
    float getStutterChance(uint32_t step, uint8_t note);

    /** @brief  Set stutter frequency
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @param  freq Stutter frequency: last bit => play/skip, higher bits => n loops to play/skip
    */
    void setStutterFreq(uint32_t step, uint8_t note, uint8_t freq);

    /** @brief  Get stutter frequency
        @param  position Quantity of steps from start of pattern at which note starts
        @param  note MIDI note number
        @retval uint8_t Note play frequency: last bit => play/skip, higher bits => n loops to play/skip
    */
    uint8_t getStutterFreq(uint32_t step, uint8_t note);

    /** @brief  Add program change to pattern
        @param  position Quantity of steps from start of pattern at which to add program change
        @param  program MIDI program change number
        @retval bool True on success
    */
    bool addProgramChange(uint32_t step, uint8_t program);

    /** @brief  Remove program change from pattern
        @param  position Quantity of steps from start of pattern at which to remove program change
        @retval bool True on success
    */
    bool removeProgramChange(uint32_t step);

    /** @brief  Get program change at a step
        @param  position Quantity of steps from start of pattern at which program change resides
        @retval uint8_t Program change (0..127, 0xFF if no program change at this step)
    */
    uint8_t getProgramChange(uint32_t step);

    /** @brief  Add continuous controller to pattern
        @param  position Quantity of steps from start of pattern at which control starts
        @param  control MIDI controller number
        @param  valueStart Controller value at start of event
        @param  valueEnd Controller value at end of event
        @param  duration Duration of event in steps
        @param  offset Step fraction, from 0.0 to 1.0
        @retval bool True on success
    */
    bool addControl(uint32_t step, uint8_t control, uint8_t valueStart, uint8_t valueEnd, float duration = 1.0, float offset = 0.0);

    /** @brief  Remove continuous controller from pattern
        @param  position Quantity of steps from start of pattern at which control starts
        @param  control MIDI controller number
    */
    void removeControl(uint32_t step, uint8_t control);

    /** @brief  Remove continuous controller from pattern inside a interval of steps
        @param  stepFrom Interval's start step (from start of pattern)
        @param  stepTo Interval's end step (from start of pattern)
        @param  control MIDI controller number
    */
    void removeControlInterval(uint32_t stepFrom, uint32_t stepTo, uint8_t control);

    /** @brief  Remove all continuous controller events from pattern
        @param  control MIDI controller number
    */
	void clearControl(uint8_t control);

    /** @brief  Get step that control starts
        @param  position Quantity of steps from start of pattern at which to check for control
        @param  control MIDI control number
        @retval int32_t Quantity of steps from start of pattern that control starts or -1 if control not found
    */
    int32_t getControlStart(uint32_t step, uint8_t control);

    /** @brief  Get duration of controller event
        @param  position Quantity of steps from start of pattern at which control starts
        @param  control MIDI controller number
        @retval float Duration of control or 0 if control does not exist
    */
    float getControlDuration(uint32_t step, uint8_t control);

    /** @brief  Get offset of control
        @param  position Quantity of steps from start of pattern at which control starts
        @param  control MIDI control number
        @retval float offset Step fraction, from 0.0 to 1.0
    */
    float getControlOffset(uint32_t step, uint8_t control);

    /** @brief  Set offset of control in selected pattern
        @param  position Quantity of steps from start of pattern at which control starts
        @param  note MIDI control number
        @param  offset Step fraction, from 0.0 to 1.0
    */
    void setControlOffset(uint32_t step, uint8_t control, float offset);

    /** @brief  Get value of control
        @param  position Quantity of steps from start of pattern at which control starts
        @param  control MIDI control number
        @retval uint8_t MIDI value of control
    */
    uint8_t getControlValue(uint32_t step, uint8_t control);

    /** @brief  Get value end of control
        @param  position Quantity of steps from start of pattern at which control starts
        @param  control MIDI control number
        @retval uint8_t end MIDI value of control
    */
    uint8_t getControlValueEnd(uint32_t step, uint8_t control);

    /** @brief  Set value of control
        @param  position Quantity of steps from start of pattern at which control starts
        @param  control MIDI control number
        @param  valueStart MIDI value at start of event
        @param  valueEdn MIDI value at end of event
    */
    void setControlValue(uint32_t step, uint8_t control, uint8_t valueStart, uint8_t valueEnd);

    /** @brief  Calculate durations and end values so CC events are joined and can be interpolated
        @param  control MIDI control number
    */
	void joinControlEvents(uint8_t control);

    /** @brief  Set duration and end values so CC events are stepped, not interpolated
        @param  control MIDI control number
    */
	void stepControlEvents(uint8_t control);

    /** @brief  Get quantity of steps in pattern
        @retval uint32_t Quantity of steps
    */
    uint32_t getSteps();

    /** @brief  Get length of pattern in clock cycles
        @retval uint32_t Length of pattern in clock cycles
    */
    uint32_t getLength();

    /** @brief  Get quantity of clocks per step
        @retval uint32_t Quantity of clocks per step
    */
    uint32_t getClocksPerStep();

    /** @brief  Set quantity of steps per beat (grid line separation)
        @param  value Quantity of steps per beat constrained to [1|2|3|4|6|8|12|24]
        @retval bool True on success
    */
    bool setStepsPerBeat(uint32_t value);

    /** @brief  Get quantity of steps per beat
        @retval uint32_t Quantity of steps per beat
    */
    uint32_t getStepsPerBeat();

    /** @brief  Set beats in pattern
        @param  beats Quantity of beats in pattern
    */
    void setBeatsInPattern(uint32_t beats);

    /** @brief  Get beats in pattern
        @retval uint32_t Quantity of beats in pattern
    */
    uint32_t getBeatsInPattern();

    /** @brief  Set map / scale used by pattern editor for this pattern
        @param  map Index of map / scale
    */
    void setScale(uint8_t scale);

    /** @brief  Get map / scale used by pattern editor for this pattern
        @retval uint8_t Index of map / scale
    */
    uint8_t getScale();

    /** @brief  Set scale tonic (root note) used by pattern editor for current pattern
        @param  tonic Scale tonic
    */
    void setTonic(uint8_t tonic);

    /** @brief  Get scale tonic (root note) used by pattern editor for current pattern
        @retval uint8_t Tonic
    */
    uint8_t getTonic();

    /** @brief  Set pattern's Swing Division
        @param  div, swing amount from 0 to 1 (0.33 is perfect-triplet swing, >0.5 is not really swing)
    */
    void setSwingDiv(uint32_t div);

    /** @brief  Get pattern's Swing Amount
        @retval float
    */
    uint32_t getSwingDiv();

    /** @brief  Set pattern's Swing Amount
        @param  amount, swing amount from 0 to 1 (0.33 is perfect-triplet swing, >0.5 is not really swing)
    */
    void setSwingAmount(float amount);

    /** @brief  Get pattern's Swing Amount
        @retval float
    */
    float getSwingAmount();

    /** @brief  Set pattern's Time Humanization amount
        @param  amount, from 0 to FLOAT_MAX
    */
    void setHumanTime(float amount);

    /** @brief  Get pattern's Time Humanization amount
        @retval float
    */
    float getHumanTime();

    /** @brief  Set pattern's Velocity Humanization amount
        @param  amount, from 0 to FLOAT_MAX
    */
    void setHumanVelo(float amount);

    /** @brief  Get pattern's Velocity Humanization amount
        @retval float
    */
    float getHumanVelo();

    /** @brief  Set pattern's PlayChance
        @param  chance, probability of playing notes
    */
    void setPlayChance(float chance);

    /** @brief  Get pattern's PlayChance
        @retval float
    */
    float getPlayChance();

    /** @brief  Transpose all notes within pattern
        @param  value Offset to transpose
    */
    void transpose(int value);

    /** @brief  Change velocity of all notes in pattern
        @param  value Offset to adjust +/-127
    */
    void changeVelocityAll(int value);

    /** @brief  Change velocity of a list of notes in pattern
        @param  value Offset to adjust +/-127
        @param  evi_list Event index list
        @param  n number of events in list
    */
    void changeVelocityList(float value, uint32_t* evi_list, uint32_t n);

    /** @brief  Change duration of all notes in pattern
        @param  value Offset to adjust +/-100.0 or whatever
    */
    void changeDurationAll(float value);

    /** @brief  Change duration of a list of notes in pattern
        @param  value Offset to adjust +/-127
        @param  evi_list Event index list
        @param  n number of events in list
    */
    void changeDurationList(float value, uint32_t* evi_list, uint32_t n);

    /** @brief  Clear all events from pattern
    */
    void clear();

    /** @brief  Get event at given index
        @param  index Index of event
        @retval StepEvent* Pointer to event or null if event does not existing
    */
    StepEvent* getEventAt(uint32_t index);

    /** @brief  Get index of first event at given time (step)
        @param  step Index of step
        @retval uint32_t Index of event or -1 if not found
    */
    int getFirstEventAtStep(uint32_t step);

    /** @brief  Get quantity of events in pattern
        @retval size_t Quantity of events
    */
    size_t getEvents();

    /** @brief  Get the reference note
        @retval uint8_t MIDI note number
        @note   May be used for position within user interface
    */
    uint8_t getRefNote();

    /** @brief  Set the reference note
        @param  MIDI note number
     May be used for position within user interface
    */
    void setRefNote(uint8_t note);

    /** @brief  Get the "Quantize Notes" value
        @retval uint8_t quantize value (0, 1, 2, 3, 4, 6, 8, 12, 16)
    */
    uint8_t getQuantizeNotes();

    /** @brief  Set the "Quantize Notes" value
        @param  quantize value (0, 1, 2, 3, 4, 6, 8, 12, 16)
    */
    void setQuantizeNotes(uint8_t qn);

    /** @brief  Get the "Interpolate CC values" flag for a given CC number
        @param  ccnum
        @retval bool flag
    */
    bool getInterpolateCC(uint8_t ccnum);

    /** @brief  Set the "Interpolate CC" flag for a given CC number
    	@param  ccnum
        @param  flag
    */
    void setInterpolateCC(uint8_t ccnum, bool flag);

    /** @brief  Set "Interpolate CC" flags to default values for each CC number
    */
    void setInterpolateCCDefaults();

    /** @brief  Get last populated step
        @retval int32_t Index of last step that contains any events or -1 if pattern is empty
    */
    int32_t getLastStep();

    // Snapshot management: Undo/Redo
    void clearStepEventVector(StepEventVector* sev);
    bool restoreSnapshot(StepEventVector* sev);
    void resetSnapshots();
    void saveSnapshot();
    bool undo();
    bool redo();
    bool undoAll();
    bool redoAll();

    // Grid zoom management
    void setZoom(int16_t zoom) { m_nZoom = zoom; }
    int16_t getZoom() { return m_nZoom; }

  private:
    void deleteEvent(uint32_t position, uint8_t command, uint8_t value1);

    StepEventVector m_vEvents;                                                   // Vector of pattern events
    std::vector<StepEventVector*> m_vSnapshots;                                  // Vector of vectors of pattern events
    std::vector<StepEventVector*>::iterator m_vSnapshotPos = m_vSnapshots.end(); // Iterator pointing to the current snapshot

    uint32_t m_nBeats = 4;         // Quantity of beats in pattern
    uint32_t m_nStepsPerBeat = 4;  // Steps per beat
    uint8_t m_nScale = 0;          // Index of scale
    uint8_t m_nTonic = 0;          // Scale tonic (root note)
    uint8_t m_nRefNote = 60;       // Note at which to position pattern editor
    uint8_t m_nQuantizeNotes = 0;  // Quantize note time so it plays in the nearest step fraction boundary (1, 1/2, 1/3, 1/4, 1/6, 1/8, 1/12, 1/16)
    bool m_bInterpolateCC[128];    // Enable/Disable CC value interpolation for each CC number
    uint32_t m_nSwingDiv = 1;      // Swing division, range from 1 to pPattern->getStepsPerBeat()
    float m_fSwingAmount = 0.0;    // Swing amount, range from 0 to 1, but over 0.5 is not "MPC swing"
    float m_fHumanTime = 0.0;      // Timing Humanization, range from 0 to FLOAT_MAX
    float m_fHumanVelo = 0.0;      // Velocity Humanization, range from 0 to FLOAT_MAX
    float m_fPlayChance = 1.0;     // Probability for playing notes (0 = Notes are not played, 0.5 = Notes plays with 50%, 1 = All notes play always)
    int16_t m_nZoom = 0;           // Grid Zoom (pattern editor)
};
