#!/usr/bin/python3
# -*- coding: utf-8 -*-
# ******************************************************************************
# ZYNTHIAN PROJECT: Zynthian GUI
#
# Zynthian GUI MIDI config Class
#
# Copyright (C) 2015-2026 Fernando Moyano <jofemodo@zynthian.org>
#                         Brian Walton <brian@riban.co.uk>
#
# ******************************************************************************
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# For a full copy of the GNU General Public License see the LICENSE.txt file.
#
# ******************************************************************************

import os
import re
import logging
from time import sleep
from threading import Thread
from subprocess import check_output, Popen, PIPE

# Zynthian specific modules
import zynconf
import zynautoconnect
from zyncoder.zyncore import lib_zyncore
from zyngine.ctrldev.zynthian_ctrldev_base import SCROLL_MODE_DISABLED, SCROLL_MODE_FIXED, SCROLL_MODE_GUI_SEL, SCROLL_MODE_GUI_VIEW, SCROLL_MODE_CTRLDEV
from zyngui import zynthian_gui_config
from zyngui.zynthian_gui_selector_info import zynthian_gui_selector_info


# ------------------------------------------------------------------------------
# Mini class to allow use of audio_in gui
# ------------------------------------------------------------------------------


class aubio_inputs():
    def __init__(self, state_manager):
        self.state_manager = state_manager
        self.audio_in = state_manager.aubio_in

    def toggle_audio_in(self, input):
        if input in self.audio_in:
            self.audio_in.remove(input)
        else:
            self.audio_in.append(input)
        self.state_manager.aubio_in = self.audio_in
        zynautoconnect.request_audio_connect()

# ------------------------------------------------------------------------------
# Zynthian MIDI config GUI Class
# ------------------------------------------------------------------------------

ZMIP_ICON_MODE_ACTIVE = "⇥"  # \u21e5
ZMIP_ICON_MODE_MULTI = "⇶"  # \u21f6
ZMIP_ICON_SEQ_EXCL = "♣"
ZMIP_ICON_MIDI_CLOCK = "⏱"  # \u23F1
#ZMIP_ICON_MIDI_SYS = "♣" # \u1
#ZMIP_ICON_MIDI_SYS_RT = "⌛"  # \u231B
ZMIP_ICON_CTRLDEV_DRIVER = "⌨"  # \u2328

class zynthian_gui_midi_config(zynthian_gui_selector_info):

    def __init__(self, parent=None, topbar=None):
        self.chain = None      # Chain object
        self.midi_input = True      # True to process MIDI inputs, False for MIDI outputs
        self.thread = None
        super().__init__('MIDI Config', parent=parent, topbar=topbar)

    def build_view(self):
        # Enable background scan for MIDI devices
        self.midi_scan = True
        self.thread = Thread(target=self.process_dynamic_ports, name="MIDI port scan")
        self.thread.start()
        return super().build_view()

    def hide(self):
        if self.shown:
            self.midi_scan = False
            self.thread = None
            super().hide()

    def set_chain(self, chain):
        self.chain = chain
        self.set_select_path()

    def fill_list(self):
        """Populate data list used for display and configuration.
        Different display mode for admin view (no chain) and chain view (i/o routing)
        List of lists, each consisting of elements based on the display mode and entry type.

        Elements in jack port:
        0: Port UID (or service name if service disabled)
        0: For services this is the name of function to start/stop service
        1: ZMIP/ZMOP index on None if not connected
        2: Display text
        """

        self.list_data = []

        def get_mode_str(idev):
            """Get input mode prefix"""
            mode_str = ""
            if idev is None:
                return mode_str
            if self.midi_input:
                port = zynautoconnect.devices_in[idev]
                if zynautoconnect.get_midi_in_dev_mode(idev):
                    mode_str += ZMIP_ICON_MODE_ACTIVE
                else:
                    mode_str += ZMIP_ICON_MODE_MULTI
                if port.aliases[0] not in zynautoconnect.get_zynseq_exclude_ports():
                    mode_str += " " + ZMIP_ICON_SEQ_EXCL
                if zynautoconnect.get_ext_clock_zmip() == idev:
                    mode_str += " " + ZMIP_ICON_MIDI_CLOCK
                #if lib_zyncore.zmip_get_flag_system(idev):
                #    mode_str += " " + ZMIP_ICON_MIDI_SYS
                #if lib_zyncore.zmip_get_flag_system_rt(idev):
                #    mode_str += " " + ZMIP_ICON_MIDI_SYS_RT
                if idev in self.zyngui.state_manager.ctrldev_manager.drivers:
                    mode_str += " " + ZMIP_ICON_CTRLDEV_DRIVER
            if mode_str:
                mode_str += " "
            return mode_str

        def get_info(text="", has_options=True):
            if has_options:
                if self.chain:
                    actions_info = "Bold select for options.\n"
                else:
                    actions_info = "Select for options.\n"
            else:
                actions_info = ""
            mode_info = ""
            if self.midi_input:
                if not self.chain:
                    actions_info += "Push #3 for MIDI OUT.\n"
                if has_options:
                    mode_info += f"ICONS KEY:\n"
                    mode_info += f"{ZMIP_ICON_MODE_ACTIVE} Active mode\n"
                    mode_info += f"{ZMIP_ICON_MODE_MULTI} Multitimbral mode\n"
                    mode_info += f"{ZMIP_ICON_SEQ_EXCL} Sequencer capture\n"
                    mode_info += f"{ZMIP_ICON_MIDI_CLOCK} MIDI Clock\n"
                    #mode_info += f"{ZMIP_ICON_MIDI_SYS} System non-RT\n"
                    #mode_info += f"{ZMIP_ICON_MIDI_SYS_RT} System RT\n"
                    mode_info += f"{ZMIP_ICON_CTRLDEV_DRIVER} Driver loaded\n"
            else:
                if not self.chain:
                    actions_info += "Push #3 for MIDI IN.\n"
            info = ""
            if text:
                info += text + "\n"
            if mode_info:
                if info:
                    info += "\n"
                info += mode_info
            return info + "\n" + actions_info

        def append_port(idev):
            """Add a port to list"""
            if self.midi_input:
                port = zynautoconnect.devices_in[idev]
                mode = get_mode_str(idev)

                if self.chain is None:
                    self.list_data.append((port.aliases[0], idev, f"{mode}{port.aliases[1]}", [get_info(), "midi_input.png"]))
                elif not self.zyngui.state_manager.ctrldev_manager.is_input_device_available_to_chains(idev):
                    self.list_data.append((port.aliases[0], idev, f"    {mode}{port.aliases[1]}", [get_info("Captured by driver."), "midi_input.png"]))
                else:
                    if lib_zyncore.zmop_get_route_from(self.chain.zmop_index, idev):
                        self.list_data.append((port.aliases[0], idev, f"\u2612 {mode}{port.aliases[1]}", [get_info("Connected to chain."), "midi_input.png"]))
                    else:
                        self.list_data.append((port.aliases[0], idev, f"\u2610 {mode}{port.aliases[1]}", [get_info("Disconnected from chain."), "midi_input.png"]))
            else:
                port = zynautoconnect.devices_out[idev]
                if port.aliases[0] in zynautoconnect.get_midi_clock_output_ports():
                    name = f"{ZMIP_ICON_MIDI_CLOCK} {port.aliases[1]}"
                else:
                    name = port.aliases[1]
                if self.chain is None:
                    self.list_data.append((port.aliases[0], idev, name, [get_info(), "midi_output.png"]))
                elif port.aliases[0] in self.chain.midi_out:
                    self.list_data.append((port.aliases[0], idev, f"\u2612 {name}", [get_info("Connected to chain."), "midi_output.png"]))
                else:
                    self.list_data.append((port.aliases[0], idev, f"\u2610 {name}", [get_info("Disconnected to chain."), "midi_output.png"]))

        def append_service(service, name, help_info="", icon="midi_logo.png"):
            try:
                idev = net_devices[name]
            except:
                idev = None
            if zynconf.is_service_active(service):
                mode = get_mode_str(idev)
                self.list_data.append((f"stop_{service}", idev, f"\u2612 {mode}{name}", [get_info(f"Disable {help_info}", False), icon]))
            else:
                self.list_data.append((f"start_{service}", idev, f"\u2610 {name}", [get_info(f"Enable {help_info}", False), icon]))

        def atoi(text):
            return int(text) if text.isdigit() else text

        def natural_keys(t):
            return [atoi(c) for c in re.split(r'(\d+)', t[0].lower())]

        # Lists of zmop/zmip indicies
        int_devices = []    # Internal MIDI ports
        usb_devices = []    # USB MIDI ports
        ble_devices = []    # BLE MIDI ports
        aubio_devices = []  # Aubio MIDI ports
        net_devices = {}    # Network MIDI ports, indexed by jack port name
        if self.midi_input:
            devs = zynautoconnect.devices_in
        else:
            devs = zynautoconnect.devices_out
        for i, dev in enumerate(devs):
            if dev and len(dev.aliases) > 1:
                if dev.aliases[0].startswith("USB:"):
                    usb_devices.append((dev.aliases[1], i))
                elif dev.aliases[0].startswith("BLE:"):
                    ble_devices.append((dev.aliases[1], i))
                elif dev.aliases[0].startswith("AUBIO:"):
                    aubio_devices.append(i)
                elif dev.aliases[0].startswith("NET:"):
                    # net_devices[dev.name] = i
                    port = devs[i]
                    puid, name = zynautoconnect.build_midi_port_name(port)
                    net_devices[name] = i
                else:
                    int_devices.append(i)

        if self.chain and self.midi_input:
            midi_chan = self.chain.midi_chan + 1
            if midi_chan > 16:
                midi_chan = "ALL"
            self.list_data.append(("MIDI Channel", None, f"MIDI Channel ({midi_chan})", [get_info("Select the MIDI channel this chain receives.", False), "midi_settings.png"]))
            self.list_data.append(("Note Range & Transpose", None, "Note Range & Transpose", [get_info("Configure note range and transpose.", False), "note_range.png"]))
            self.list_data.append(("MIDI CC", None, "MIDI CC",
                                   [get_info("Select MIDI CC numbers passed-thru to chain processors. It could interfere with MIDI-learning. Use with caution!", False),
                                    "midi_settings.png"]))

        self.list_data.append((None, None, "INTERNAL DEVICES"))
        nint = len(self.list_data)

        for i in int_devices:
            append_port(i)

        if self.midi_input:
            if not self.chain or zynthian_gui_config.midi_aubionotes_enabled:
                if self.chain:
                    for i in aubio_devices:
                        append_port(i)
                else:
                    append_service("aubionotes", "Aubionotes (Audio \u2794 MIDI)",
                                   "Aubionotes. Converts audio input to MIDI note on/off commands.", "midi_audio.png")

        # Remove "Internal Devices" title if section is empty
        if len(self.list_data) == nint:
            self.list_data.pop()

        if usb_devices:
            self.list_data.append((None, None, "USB DEVICES"))
            for x in sorted(usb_devices, key=natural_keys):
                append_port(x[1])

        if self.chain is None or ble_devices:
            self.list_data.append((None, None, "BLUETOOTH DEVICES"))
            if self.chain is None:
                append_service("bluetooth", "BLE MIDI", "Bluetooth MIDI.", "midi_bluetooth.png")
            for x in sorted(ble_devices, key=natural_keys):
                append_port(x[1])

        if not self.chain or net_devices:
            self.list_data.append((None, None, "NETWORK DEVICES"))
            if self.chain:
                for i in net_devices.values():
                    append_port(i)
            else:
                if os.path.isfile("/usr/local/bin/jacknetumpd"):
                    append_service("jacknetumpd", "Network MIDI 2.0",
                                   "Network MIDI 2.0. Provides MIDI over an IP connection using Network MIDI 2.0 protocol.", "midi_network.png")

                if os.path.isfile("/usr/local/bin/jackrtpmidid"):
                    append_service("jackrtpmidid", "RTP MIDI",
                                   "RTP-MIDI. Provides MIDI over an IP connection using RTP-MIDI protocol (AppleMIDI).", "midi_network.png")

                if os.path.isfile("/usr/local/bin/qmidinet"):
                    append_service("qmidinet", "QmidiNet",
                                   "QmidiNet. Provides MIDI over an IP connection using UDP/IP multicast (ipMIDI).", "midi_network.png")

                if os.path.isfile("/zynthian/venv/bin/touchosc2midi"):
                    append_service("touchosc2midi", "TouchOSC",
                                   "Interface with Hexler TouchOSC modular control surface.", "midi_network.png")

        a2m_ports = zynautoconnect.get_a2m_ports()
        if self.midi_input and self.chain and a2m_ports:
            self.list_data.append((None, None, "> AUDIO => MIDI"))
            for name, title in a2m_ports:
                if name in self.chain.midi_in:
                    self.list_data.append(("audio2midi", name, f"\u2612 {title}", [get_info("Connected from chain.", False), "midi_audio.png"]))
                else:
                    self.list_data.append(("audio2midi", name, f"\u2610 {title}", [get_info("Disconnected from chain.", False), "midi_audio.png"]))

        if not self.midi_input and self.chain:
            self.list_data.append((None, None, "> CHAINS"))
            len_check = len(self.list_data)
            for i, chain_id in enumerate(self.zyngui.chain_manager.chains):
                chain = self.zyngui.chain_manager.get_chain(chain_id)
                if chain and chain.is_midi() and chain != self.chain and chain.midi_chan < 16:
                    if self.zyngui.chain_manager.will_midi_howl(self.zyngui.chain_manager.active_chain.chain_id, chain_id):
                        prefix = "∞ "
                    else:
                        prefix = ""
                    if chain_id in self.chain.midi_out:
                        self.list_data.append((chain_id, None, f"\u2612 {prefix}{chain.get_name()}", [get_info("Connected to chain.", False), "midi_output.png"]))
                    else:
                        self.list_data.append((chain_id, None, f"\u2610 {prefix}{chain.get_name()}", [get_info("Disconnected from chain.", False), "midi_output.png"]))
            if len(self.list_data) == len_check:
                self.list_data.pop() # Remove section title for empty section

        super().fill_list()

    def select_action(self, i, t='S'):
        if t == 'S':
            action = self.list_data[i][0]
            wait = 2  # Delay after starting service to allow jack ports to update
            if action == "stop_jacknetumpd":
                self.zyngui.state_manager.stop_netump(wait=wait)
            elif action == "start_jacknetumpd":
                self.zyngui.state_manager.start_netump(wait=wait)
            elif action == "stop_jackrtpmidid":
                self.zyngui.state_manager.stop_rtpmidi(wait=wait)
            elif action == "start_jackrtpmidid":
                self.zyngui.state_manager.start_rtpmidi(wait=wait)
            elif action == "stop_qmidinet":
                self.zyngui.state_manager.stop_qmidinet(wait=wait)
            elif action == "start_qmidinet":
                self.zyngui.state_manager.start_qmidinet(wait=wait)
            elif action == "stop_touchosc2midi":
                self.zyngui.state_manager.stop_touchosc2midi(wait=wait)
            elif action == "start_touchosc2midi":
                self.zyngui.state_manager.start_touchosc2midi(wait=wait)
            elif action == "stop_aubionotes":
                self.zyngui.state_manager.stop_aubionotes(wait=wait)
            elif action == "start_aubionotes":
                self.zyngui.state_manager.start_aubionotes(wait=wait)
            elif action == "stop_bluetooth":
                self.zyngui.state_manager.stop_bluetooth(wait=wait)
            elif action == "start_bluetooth":
                self.zyngui.state_manager.start_bluetooth(wait=wait)
            # Route/Unroute
            elif self.chain:
                if action == "MIDI Channel":
                    self.zyngui.screens['midi_chan'].set_mode("SET", self.chain.midi_chan, chan_all=True)
                    self.zyngui.show_screen('midi_chan')
                    return
                elif action == "MIDI CC":
                    self.zyngui.screens['midi_cc'].set_chain(self.chain)
                    self.zyngui.show_screen('midi_cc')
                    return
                elif action == "Note Range & Transpose":
                    self.zyngui.screens['midi_key_range'].config(self.chain)
                    self.zyngui.show_screen('midi_key_range')
                    return
                elif action == "audio2midi":
                    self.chain.toggle_midi_in(self.list_data[i][1])
                else:
                    # Change mode
                    idev = self.list_data[i][1]
                    if self.midi_input:
                        if not self.zyngui.state_manager.ctrldev_manager.is_input_device_available_to_chains(idev):
                            return
                        lib_zyncore.zmop_set_route_from(self.chain.zmop_index, idev, not lib_zyncore.zmop_get_route_from(self.chain.zmop_index, idev))
                    else:
                        try:
                            if idev is not None:
                                dev_id = zynautoconnect.get_midi_out_dev(idev).aliases[0]
                                self.chain.toggle_midi_out(dev_id)
                            elif isinstance(action, int):
                                self.chain.toggle_midi_out(action)
                        except Exception as e:
                            logging.error(e)
            else:
                self.show_options()
                return
        elif t == 'B':
            self.show_options()
            return
        self.update_list()

    def set_mode(self, input):
        self.midi_input = input
        if self.shown:
            self.set_select_path()
            self.update_list()

    def set_mode_input(self):
        self.set_mode(True)

    def set_mode_output(self):
        self.set_mode(False)

    def toggle_mode(self):
        self.set_mode(not self.midi_input)

    def switch(self, i, t):
        if not self.chain:
            if i == 2 and t == 'S':
                self.toggle_mode()
                return True
        return False

    def cuia_v5_zynpot_switch(self, params):
        if not self.chain:
            i = params[0]
            t = params[1].upper()
            if i == 2 and t == 'S':
                self.toggle_mode()
                return True
        return False

    def show_menu(self):
        if self.shown:
            return self.show_options()
        else:
            return False

    def show_options(self):
        try:
            idev = self.list_data[self.index][1]
            if idev is None:
                return False
            options = {}
            if self.midi_input:
                port = zynautoconnect.devices_in[idev]
                screen_title = f"MIDI-IN: {port.aliases[1]}"

                options["Options"] = None
                opt_info = "Toggle input mode.\n\n"
                if zynautoconnect.get_midi_in_dev_mode(idev):
                    if lib_zyncore.get_active_midi_chan():
                        opt_info += f"{ZMIP_ICON_MODE_ACTIVE}: Active chain.\n\nTranslate MIDI channel. Send to chains matching active chain's MIDI channel."
                    else:
                        opt_info += f"{ZMIP_ICON_MODE_ACTIVE}: Active chain.\n\nTranslate MIDI channel. Send to active chain only."
                    options["Input mode (Active chain)"] = ["MODE_MULTI", [opt_info, "midi_input.png"]]
                else:
                    opt_info += f"{ZMIP_ICON_MODE_MULTI}: Multitimbral.\n\nDon't translate MIDI channel. Send to chains matching device's MIDI channel."
                    options["Input mode (Multitimbral)"] = ["MODE_ACTI", [opt_info, "midi_input.png"]]

                opt_info = f"Toggle sequencer capture.\n\n{ZMIP_ICON_SEQ_EXCL}: Sequencer.\n\nUse this input device for live recording from the step sequencer."
                if port.aliases[0] in zynautoconnect.get_zynseq_exclude_ports():
                    options[f"\u2610 Sequencer capture"] = [idev, [opt_info, "midi_input.png"]]
                else:
                    options[f"\u2612 Sequencer capture"] = [idev, [opt_info, "midi_input.png"]]

                opt_info = f"Toggle MIDI clock.\n\n{ZMIP_ICON_MIDI_CLOCK}: MIDI Clock.\n\nSync to MIDI clock from this device.\nThis is an exclusive option that will disable syncing from other devices."
                if zynautoconnect.get_ext_clock_zmip() == idev:
                    options[f"\u2612 MIDI Clock Source"] = ["MIDI_CLOCK/OFF", [opt_info, "midi_input.png"]]
                else:
                    options[f"\u2610 MIDI Clock Source"] = ["MIDI_CLOCK/ON", [opt_info, "midi_input.png"]]

                """
                opt_info = "Route non real-time system messages from this device.\n\n"
                if lib_zyncore.zmip_get_flag_system(idev):
                    title = f"\u2612 {ZMIP_ICON_MIDI_SYS} Non real-time messages"
                    options[title] = ["MIDI_SYS/OFF", [opt_info, "midi_input.png"]]
                else:
                    title = f"\u2610 {ZMIP_ICON_MIDI_SYS} Non real-time messages"
                    options[title] = ["MIDI_SYS/ON", [opt_info, "midi_input.png"]]

                opt_info = "Route real-time system messages from this device.\n\n"
                if lib_zyncore.zmip_get_flag_system_rt(idev):
                    title = f"\u2612 {ZMIP_ICON_MIDI_SYS_RT} Real-time transport messages"
                    options[title] = ["MIDI_SYS_RT/OFF", [opt_info, "midi_input.png"]]
                else:
                    title = f"\u2610 {ZMIP_ICON_MIDI_SYS_RT} Real-time transport messages"
                    options[title] = ["MIDI_SYS_RT/ON", [opt_info, "midi_input.png"]]
                """

                # Reload drivers => Hot reload the driver classes!
                #self.zyngui.state_manager.ctrldev_manager.update_available_drivers(reload_modules=False)
                # Get driver list for the device (dev_id) connected to this slot (idev)
                dev_id = zynautoconnect.get_midi_in_devid(idev)
                available_drivers = self.zyngui.state_manager.ctrldev_manager.available_drivers
                loaded_drivers = self.zyngui.state_manager.ctrldev_manager.drivers
                # Get available drivers for this device ...
                device_drivers = []
                # Specific drivers
                try:
                    device_drivers += available_drivers[dev_id]
                except:
                    pass
                # Generic drivers
                if idev < lib_zyncore.zmip_get_seq_index():
                    try:
                        device_drivers += available_drivers["*"]
                    except:
                        pass
                driver_options = {}
                for i, driver_class in enumerate(device_drivers):
                    driver_name = driver_class.get_driver_name()
                    driver_description = driver_class.get_driver_description()
                    if not driver_description:
                        driver_description = "Device driver integrating UI functions and customized workflow."
                    driver_description = f"{ZMIP_ICON_CTRLDEV_DRIVER}: Driver.\n\n{driver_description}"
                    if idev in loaded_drivers and type(loaded_drivers[idev]) is driver_class:
                        driver_options[f"\u2612 {driver_name}"] = [
                            ["UNLOAD_DRIVER", driver_class.__name__], [driver_description, "midi_input.png"]]
                    else:
                        driver_options[f"\u2610 {driver_name}"] = [
                            ["LOAD_DRIVER", driver_class.__name__], [driver_description, "midi_input.png"]]
                if driver_options:
                    options[f"Drivers {ZMIP_ICON_CTRLDEV_DRIVER}"] = None
                    options.update(driver_options)

            else:
                port = zynautoconnect.devices_out[idev]
                screen_title = f"MIDI-OUT: {port.aliases[1]}"
                options["Options"] = None
                opt_info = "Send MIDI clock to this device."
                if port.aliases[0] in zynautoconnect.get_midi_clock_output_ports():
                    options[f"\u2612 {ZMIP_ICON_MIDI_CLOCK} Send MIDI Clock"] = [idev, [opt_info, "midi_output.png" ]]
                else:
                    options[f"\u2610 {ZMIP_ICON_MIDI_CLOCK} Send MIDI Clock"] = [idev, [opt_info, "midi_output.png" ]]

            options["Advanced"] = None
            if self.list_data[self.index][0].startswith("AUBIO:") or self.list_data[self.index][0].endswith("aubionotes"):
                options["Select aubio inputs"] = ["AUBIO_INPUTS", ["Select audio inputs to be analized and converted to MIDI.", "midi_audio.png"]]
            options[f"Rename port '{port.aliases[0]}'"] = [port, ["Rename the MIDI port.\nClear name to reset to default name.",  "midi_input.png"]]
            # options[f"Reset name to '{zynautoconnect.build_midi_port_name(port)[1]}'"] = port

            self.zyngui.screens['option'].config(screen_title, options, self.menu_cb, False, True, None)
            self.zyngui.show_screen('option')
            return True
        except Exception as e:
            logging.error(e)
            #pass  # Port may have disappeared whilst building menu
        return False

    def menu_cb(self, option, params, click_type):
        try:
            if option.startswith("Rename port"):
                self.zyngui.show_keyboard(self.rename_device, params.aliases[1])
                return
            elif option.startswith("Reset name"):
                zynautoconnect.set_port_friendly_name(params)
            elif option.endswith("Send MIDI Clock"):
                zynautoconnect.toggle_midi_clock_output_zmop(params)
            elif option.endswith("Sequencer capture"):
                zynautoconnect.toggle_zynseq_input_zmop(params)
            elif isinstance(params, list):
                idev = self.list_data[self.index][1]
                if click_type == "B":
                    self.show_controller_options(idev)
                    return
                elif params[0] == "LOAD_DRIVER":
                    #logging.debug(f"LOAD DRIVER FOR {idev}")
                    self.zyngui.state_manager.ctrldev_manager.load_driver(idev, params[1])
                elif params[0] == "UNLOAD_DRIVER":
                    #logging.debug(f"UNLOAD DRIVER FOR {idev}")
                    self.zyngui.state_manager.ctrldev_manager.unload_driver(idev,True)
            elif isinstance(params, str):
                if params == "AUBIO_INPUTS":
                    ain = aubio_inputs(self.zyngui.state_manager)
                    self.zyngui.screens['audio_in'].set_chain(ain)
                    self.zyngui.show_screen('audio_in')
                    return
                elif self.midi_input:
                    idev = self.list_data[self.index][1]
                    match params:
                        case "MODE_ACTI":
                            lib_zyncore.zmip_set_flag_active_chain(idev, True)
                            zynautoconnect.update_midi_in_dev_mode(idev)
                        case "MODE_MULTI":
                            lib_zyncore.zmip_set_flag_active_chain(idev, False)
                            zynautoconnect.update_midi_in_dev_mode(idev)
                        case "MIDI_CLOCK/ON":
                            zynautoconnect.set_ext_clock_zmip(idev)
                        case "MIDI_CLOCK/OFF":
                            zynautoconnect.set_ext_clock_zmip(-1)
                    """
                    case "MIDI_SYS/ON":
                        lib_zyncore.zmip_set_flag_system(idev, True)
                    case "MIDI_SYS/OFF":
                        lib_zyncore.zmip_set_flag_system(idev, False)
                    case "MIDI_SYS_RT/ON":
                        lib_zyncore.zmip_set_flag_system_rt(idev, True)
                    case "MIDI_SYS_RT/OFF":
                        lib_zyncore.zmip_set_flag_system_rt(idev, False)
                    """
            self.show_options()
            self.update_list()
        except Exception as e:
            #logging.error(e)
            pass  # Ports may have changed since menu opened

    def show_controller_options(self, idev):
        """ Show hardware controller options view
        Params:
            idev: Index of controller's MIDI port
        """

        # TODO: Check what modes controller supports
        try:
            options = {}
            # Scroll options
            mode = self.zyngui.state_manager.ctrldev_manager.drivers[idev].get_scroll_mode()
            if mode > 0:
                options["Scroll Modes"] = None
                options["Locked (no scroll)"] = ("scroll_mode", idev, SCROLL_MODE_FIXED)
                options["Follow GUI selection"] = ("scroll_mode", idev, SCROLL_MODE_GUI_SEL)
                options["Follow GUI view"] = ("scroll_mode", idev, SCROLL_MODE_GUI_VIEW)
                options["Driver custom"] = ("scroll_mode", idev, SCROLL_MODE_CTRLDEV)
            if options:
                self.zyngui.screens['option'].config("Controller Options", options, self.controller_options_cb, index=mode+1)
                self.zyngui.show_screen('option')
        except:
            pass

    def controller_options_cb(self, option, params):
        cmd, idev, val = params
        try:
            if cmd == "scroll_mode":
                self.zyngui.state_manager.ctrldev_manager.drivers[idev].set_scroll_mode(cal)
        except:
            logging.warning(f"Failed to set ctrldev option for device {idev}: {cmd}({val}) ")
        self.show_options()

    def process_dynamic_ports(self):
        """Process dynamically added/removed MIDI devices"""

        if self.midi_input:
            last_fingerprint = zynautoconnect.get_hw_src_ports()
        else:
            last_fingerprint = zynautoconnect.get_hw_dst_ports()

        while self.midi_scan:
            if self.midi_input:
                fingerprint = zynautoconnect.get_hw_src_ports()
            else:
                fingerprint = zynautoconnect.get_hw_dst_ports()
            if last_fingerprint != fingerprint:
                last_fingerprint = fingerprint
                self.update_list()

            sleep(2)  # Repeat every 2s

    def rename_device(self, name):
        """Set the friendly name of selected

        name : New friendly name
        """

        if self.midi_input:
            port = zynautoconnect.devices_in[self.list_data[self.index][1]]
        else:
            port = zynautoconnect.devices_out[self.list_data[self.index][1]]
        zynautoconnect.set_port_friendly_name(port, name)
        self.update_list()
        self.zyngui.close_screen("option")

    def set_select_path(self):
        if self.chain:
            if self.midi_input:
                self.select_path.set(f"{self.chain.get_name()}/MIDI Input")
            else:
                self.select_path.set(f"{self.chain.get_name()}/MIDI Output")
        else:
            if self.midi_input:
                self.select_path.set(f"MIDI Input Devices")
            else:
                self.select_path.set(f"MIDI Output Devices")

# ------------------------------------------------------------------------------
